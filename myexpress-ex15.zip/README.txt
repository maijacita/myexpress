HTML tiedosto: Koodattu verkkosivu,
mikä voidaan näytätä verkkoselaimessa.
JS: Tekstitiedosto, mikä sisältää riviä
javascript-koodia.